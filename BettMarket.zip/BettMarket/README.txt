BettMarket - skedari i faqes
index.html -> faqja e plote. Ngarko ne GitHub: Add file -> Upload files -> Commit; pastaj Settings -> Pages -> main / (root).
Shenim: jashte artefaktit te Claude faqja punon ne modalitet lokal (llogarite ruhen vetem ne shfletuesin tend).
