BettMarket - skedari i faqes
============================
index.html  -> faqja e plote (hapet direkt ne shfletues ose ngarkohet ne GitHub Pages)

Ngarkimi ne GitHub: repository -> Add file -> Upload files -> index.html -> Commit.
Pastaj Settings -> Pages -> Deploy from a branch -> main / (root).

Shenim: jashte artefaktit te Claude, faqja punon ne modalitet lokal.
Llogarite dhe bastet ruhen vetem ne shfletuesin ku hapet, dhe nuk ndahen mes njerezve.
Per llogari te perbashketa perdor linkun e artefaktit me Share (Contributor).
